#Python Diretório/nome_arquivo.py -> Isto irá executar o algoritmo desejado
#Comando LS                       -> irá listra os arquivos e diretórios na pasta
#Comando CD Diretório             -> Entra no diretório desejado
#Comando cd..                     -> Volta para o diretório anterior
#Comando Clear                    -> Limpa o console
#Comando ctrl + c                 -> Mata o algoritmo se quiser parar de executar
#Seta pra cima ou pra baixo       -> Navega entre comandos anteriores

print("**** Bem Vindo a calculadora de IMC ****")
peso = float(input("Digite seu peso: "))
altura = float(input("Digite sua altura: "))

imc = peso / (altura * altura)

print(f"O Seu imc é {imc:.2f}")