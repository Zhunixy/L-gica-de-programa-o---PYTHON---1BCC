while True:
    print("---Menu de Exercícios---")
    print("Escolha uma opção")
    print("1. Imprimir os números de 1 a 10 usando um loop. ")
    print("2. Imprimir os números pares de 0 a 20 usando um loop.")
    print("3. Imprimir a soma dos números de 1 a 100 usando um loop.")
    print("4. Imprimir os números de 1 a 10 em ordem reversa usando um loop.")
    print("5. Imprimir os números ímpares de 1 a 20 usando um loop.")
    print("6. Suponha que você tenha uma lista de números inteiros e queira imprimir o índice e o número correspondente apenas para os números ímpares. Escreva um programa que percorra a lista de números e imprima o índice e o número para cada número ímpar utilizando a função enumerate(). Utilizar a lista: [2, 5, 8, 11, 14]")
    print("7. Imprimir os números de 1 a 100 que são divisíveis por 3 usando um loop.")
    print("8. Faça um cadastro que grave nomes em uma lista (min. 10) e após isso imprima cada nome junto com sua posição na lista. ")
    print("9. Neste exercício, você deverá criar um cadastro de uma lista de compras de um supermercado contendo pelo menos 10 itens. Em seguida, crie um laço que irá executar enquanto ainda houver itens na lista de compras. Dentro desse laço, o programa deverá exibir o número do item na lista juntamente com o seu nome.")
    print("10. Crie 3 listas (jogo, preço e avaliação (nota de 1 a 10)) e faça o cadastro dessas 3 listas.")
    opcao = int(input())

    if opcao == 1:
        for i in range(1,11):
            print(i)
    elif opcao == 2:
        for i in range(0, 20):
            if i%2 != 0:
                print(i + 1)
    elif opcao == 3:
        soma = 1
        for i in range(2,101):
            print(f"{i} + {soma} = {i+soma}")
            soma+=i
    elif opcao == 4:
        for i in reversed(range(0, 10)):
            print(i+1)
    elif opcao == 5:
        for i in range(1,11):
            if i % 2 != 0:
                print(i)
    elif opcao == 6:
        lista = [2, 5, 8, 11, 14]
        for indice, i in enumerate(lista):
            if i%2 != 0:
                print(f"{indice+1}){i}")
        print(lista)
    elif opcao == 7:
        for i in range(1,101):
            if i % 3 == 0:
                print(i)
    elif opcao == 8:
        listanomes = []
        nomes = int(input("Digite quantos nomes deseja adicionar (minímo [10] nomes): "))
        if nomes >= 10:
            print(f"({nomes}) á serem cadastrados")

            for i in range(0, nomes):
                print(f"\nDigite o nome a ser adicionar ({i+1}): ")
            listanomes.append(input())
        else:
            print(f"O minímo de nomes são (10)")
        print(listanomes)
        for indice1, i1 in enumerate(listanomes):
            print(f"{indice1+1}){i1}")
    elif opcao == 9:
        lista_compras = []

        qtd_compras = int(input("Digite a Quantidade Dos Produtos: "))

        if qtd_compras > 9:
            for i in range(0, qtd_compras):
                lista_compras.append(input(f"Digite o produto N°{i+1} "))
            for i in range(0, 10):
                print("Digite o produto a ser comprado: ")
            for indice, produto in enumerate(lista_compras):
                print(f"Nome do produto N°{indice+1}: {produto} ")
        try:
            lista_compras.remove(input("Digite o código do item para remover da lista"))
        except:
            print("O Código digitado não existe na lista ou voce não digitou corretamente")
            if len(lista_compras) <= 0:
                break
            print("Produtos comprados")
        else:
            print("Selecione pelomenos 10 produtos a serem comprados")
    elif opcao == 10:

        listajogo = []
        listavalor = []
        listanota = []
        qtdejogos = int(input("Digite quantos jogos você deseja adicionar: "))
        for i in range(0, qtdejogos):
            print(f"\nDigite o nome do jogo a ser adicionar: {i+1}")
        listajogo.append(input())
        print(f"\nDigite o valor do jogo a ser adicionar: {i+1}")
        listavalor.append(input())
        print(f"\nDigite a nota do jogo a ser adicionar: {i+1}")
        listanota.append(input())
        print(f"{listajogo},{listavalor},{listanota}")
        indicemelhor = listanota.index(max(listanota))
        print(f"\n Melhor avaliado: Nome: {listajogo[indicemelhor]}, Preço: R${listavalor[indicemelhor]}, Nota: {listanota[indicemelhor]}")
        print("\n ######################################################")
        indicepior = listanota.index(min(listanota))
        print(f"\n Pior avaliado: Nome: {listajogo[indicepior]}, Preço: R${listavalor[indicepior]}, Nota: {listanota[indicepior]}")
        print("\n ######################################################")
        valorcaro = listavalor.index(max(listavalor))
        print(f"\n Mais caro: Nome: {listajogo[valorcaro]}, Preço: R${listavalor[valorcaro]}, Nota: {listanota[valorcaro]}")
        print("\n ######################################################")
        valorbarato = listavalor.index(min(listavalor))
        print(f"\n Mais barato: Nome: {listajogo[valorbarato]}, Preço: R${listavalor[valorbarato]}, Nota: {listanota[valorbarato]}")
        print("\n ######################################################")
        print("\n Todos os jogos adicionados:")
        for all in range(len(listajogo)):
            print(f"\n Nome: {listajogo[all]}, Preço: R${listavalor[all]}, Nota: {listanota[all]}")
    else:
        print("Digitou uma opção inválida")