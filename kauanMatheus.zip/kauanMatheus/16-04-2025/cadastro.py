import os #Importação da biblioteca de sistema operacional
from getpass import getpass #Ocultar digitação da senha

if not os.path.exists("arquivos"): #Verifica dentro do sistema operacional se o diretório "arquivos" existe
    os.makedirs("arquivos") #Se não existir, eu crio ele

usuarios = [] #criando lista vazia de usuários
senhas = [] #criando lista vazia de senhas

while True:
    print("==================================================")
    opcao = int(input("Digite 0 para cadastrar e 1 para sair: "))
    if opcao == 1:
        print("Saindo do laço...")
        break #Encerra o laço
    elif opcao == 0:
        usuarios.append(input("Digite o login: ")) #Alimentando a lista de usuários
        senhas.append(getpass("Digite a senha: ")) #Alimentando lista de senhas
    else:
        print("Escolha uma opção válida")

    print("==================================================")
with open("arquivos/senhas.txt", "a+") as arquivo: #a+ preserva o conteudo ja escrito e escreve a mais
    for indice,usuario in enumerate(usuarios):
        arquivo.write(usuario + ";" + senhas[indice] + "\n") # + \n somando o usuario com a quebra de linha


