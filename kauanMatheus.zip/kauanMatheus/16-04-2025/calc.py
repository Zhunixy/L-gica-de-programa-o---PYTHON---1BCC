print("="*50)
print("Bem-Vindo a calculadora em python")
print("="*50)
try:
    n1 = float(input("Digite um número:"))
    n2 = float(input("Digite outro número:"))

    print("+ : Adição")
    print("- : Subtração")
    print("* : Multiplicação")
    print("/ : Divisão")
    print("="*50)

    opcao = input("Selecione a operação desejada:")

    if opcao == "+":
        print(f"{n1} + {n2} = {n1+n2:.2f}")
    elif opcao == "-":
        print(f"{n1} - {n2} = {n1-n2:.2f}")
    elif opcao == "*":
        print(f"{n1} * {n2} = {n1*n2:.2f}")
    elif opcao == "/":
        print(f"{n1} / {n2} = {n1/n2:.2f}")
    else:
        print("Operação inválida")
except:
    print("Digite apenas números!")