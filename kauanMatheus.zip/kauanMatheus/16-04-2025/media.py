print("**** Bem vindo ao calculador de média ****")
qtd_notas = int(input("Digite a quantidade de notas: "))
notas = []

for i in range(0,qtd_notas):
    notas.append(float(input(f"Digite a {i+1} nota: ")))
media = sum(notas) / len(notas) #Função SUM() para somar todos os elementos da lista
print(f"A média das notas {notas} é {media:.2f}")